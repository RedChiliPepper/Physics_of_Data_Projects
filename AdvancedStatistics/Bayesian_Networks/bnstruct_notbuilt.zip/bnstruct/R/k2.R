alpha<-function(son,parent,df){
  
  if(length(parent)==0){
      df_s_p<-df[son]
      alpha<-c(table(df_s_p)) 
  }
  else{
    
    df_s_p <- cbind(df[son],df[parent])
    alpha<-c(table(df_s_p)) # table counts the number of combinations (0,0,0), (0,0,1), ...

  }
    
  return(alpha)  
}

score_flag <- function(son, par, df, flag = TRUE){
    
    r <- length(unique(df[,son]))
    alp <-alpha(son, par, df)
    
    if(length(par)==0){
        
        N <- sum(alp)
        
        if(flag == TRUE){
            
        fact_list <- sapply(alp, lfactorial)
        pr <- sum(fact_list)
        prob <- pr + lfactorial((r-1)) - lfactorial((N + r - 1))

        }

        else{
            
            fact_list <- sapply(alp,factorial)
            pr<-prod(fact_list)
            prob<-pr*factorial((r-1))/factorial((N+r-1))
        }
        
    }
    
    else {
        
        M <- matrix(alp, nrow = r)
        N <- apply(M, 2, sum)

        if(flag == TRUE){
            
            pr_list <- apply(apply(M,c(1,2), lfactorial), 2, sum)
            prob <- 0
            
            for (i in 1:length(N)) {
                plus <- pr_list[i] + lfactorial(r-1)
                minus <- lfactorial(N[i]+r-1)
                prob <- prob + pr_list[i] + lfactorial(r-1) - lfactorial(N[i]+r-1)
                }
            
        }
        else{
            
            pr_list <- apply(apply(M, c(1,2), factorial), 2, prod)
            prob <- 1
            
            for (i in 1:length(N)) {
                
                num <- pr_list[i]*factorial(r-1)
                den <- factorial(N[i]+r-1)
                prob <- prob*pr_list[i]*factorial(r-1)/factorial(N[i]+r-1)

                }
            
        }
  }
  
 return(prob)
  
}


K2_algorithm_bnstruct <- function(bndf, max_parents, flag=TRUE, order, envir = environment()){
    
    if (has.imputed.data(bndf)) {
        df <- as.data.frame(imputed.data(bndf))
    }
    else {
        df <- as.data.frame(raw.data(bndf))
    }
    
    colnames(df) <- variables(bndf)
    
    order <- if (missing(order)) 1:ncol(df) else eval(substitute(order), envir)

    n <- ncol(df) #same as length nodes

    if (identical(names(df), NULL)){
        nodes <- sprintf("x%s",seq(1:n))
        colnames(df) <- nodes
    }
    else{
        nodes <- names(df)
    }
    t_order <- data.table(cbind(order, nodes))
    score <- c()
    adj   <- matrix(0, nrow=n, ncol=n)
    rownames(adj) <- nodes
    colnames(adj) <- nodes

        for (i in 1:n){
        
        parent <- c()

        P_old <- score_flag(nodes[i], parent, df, flag)

        ok <- TRUE

        pred_xi <- unlist(t_order$nodes[t_order$order < t_order$order[i]]) #we want the previous nodes, so the ones up to the i-th node
        #idx_pred_xi <- which(colnames(df) == pred_xi) if we want to use numbers instead of names
        
        while (ok & length(parent) < max_parents){ #parent is p_i
            
            diff <- setdiff(pred_xi, parent) #setdiff(idx_pred_xi, parent) if we want to work with indexes instead of names #elements of setdiff(x,y) are those elements in x but not in y, difference is between _sets_
            unions <- lapply(diff, union, parent)
            new_parent <- unlist(unions[which.max(sapply(unions, function(x) score_flag(nodes[i], unlist(x), df, flag)))])
            P_new <- score_flag(nodes[i], new_parent, df, flag)
            
            if (P_new > P_old){
                P_old <- P_new
                parent <- new_parent
            }
                                                         
            else ok <- FALSE      
        }                                            
        
        score <- c(score, P_old)
        adj[i, parent] <- 1
        
        x_i <- t_order$nodes[i]
        if (identical(parent, NULL)) parents_print <- 'None' else parents_print <- parent

        cat('Node:',x_i,'\t\t ------ Parents of node', x_i,'are \t p', x_i, '=',parents_print,'\n')
    }

    
    if (flag) score <- (sum(score)) else score <- log(prod(score))
    cat('Network score :', round(score/nrow(df),3))

    return(adj)
}