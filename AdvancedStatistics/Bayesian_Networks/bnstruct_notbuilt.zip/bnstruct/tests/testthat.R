library(testthat)
test_check("bnstruct")
